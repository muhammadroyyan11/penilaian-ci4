
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?=base_url()?>/assets/assets/vendor/libs/jquery/jquery.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/popper/popper.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/js/bootstrap.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/node-waves/node-waves.js"></script>

    <script src="<?=base_url()?>/assets/assets/vendor/libs/hammer/hammer.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/i18n/i18n.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/typeahead-js/typeahead.js"></script>

    <script src="<?=base_url()?>/assets/assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?=base_url()?>/assets/assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js"></script>
    <script src="<?=base_url()?>/assets/assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js"></script>

    <!-- Main JS -->
    <script src="<?=base_url()?>/assets/assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="<?=base_url()?>/assets/assets/js/pages-auth.js"></script>
  </body>
</html>